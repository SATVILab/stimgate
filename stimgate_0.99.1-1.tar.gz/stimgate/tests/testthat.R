library(testthat)
library(stimgate)

test_check("stimgate")
